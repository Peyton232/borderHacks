from django.db import models

class Host(models.Model):
	Url = models.URLField()

