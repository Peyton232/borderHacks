from django.apps import AppConfig


class BorderhacksConfig(AppConfig):
    name = 'BorderHacks'
