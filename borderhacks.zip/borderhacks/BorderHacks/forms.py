from django import forms
from models import Host
# Create your models here.

class HostForm(forms.Form):
	class Meta:
		model = Host
		fields = '__all__'

	
